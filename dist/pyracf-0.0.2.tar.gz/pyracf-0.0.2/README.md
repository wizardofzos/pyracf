# pyracf

## parsing IRRDBU00 unloads like a boss

    from pyracf import RACF
    RACF.parse('path/to/irrdbu00')
    RACF.users.info()

    