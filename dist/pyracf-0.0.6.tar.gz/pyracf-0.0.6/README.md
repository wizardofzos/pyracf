# pyracf

## Parsing IRRDBU00 unloads like a boss

    >>> from pyracf import RACF
    >>> mysys = RACF('/path/to/irrdbu00')
    >>> mysys.parse()
    >>> mysys.status
    {'status': 'Still parsing your unload', 'lines-read': 200392, 'lines-parsed': 197269, 'lines-per-second': 63934, 'parse-time': 'n.a.'}
    >>> mysys.status
    {'status': 'Ready', 'lines-read': 7137540, 'lines-parsed': 2248149, 'lines-per-second': 145048, 'parse-time': 49.207921}
    

## All functions

| Function/Property | Explanation | Example |
|---|---|---|
| auditors | Returns DataFrame with all user having the auditor bit switched on | mysys.auditors |
| connects | Returns DataFrame with all user to group connects | mysys.connects |
| datasetAccess | Returns DataFrame with all Accesslists for all dataset profiles | mysys.datasetsAccess |
| datasets | Returns DataFrame with all datasetprofiles | mysys.datasets |
| genericAccess | Returns DataFrame with with all accesslists for generic resource profiles | mysys.genericAccess
| generics | Returns DataFrame with with all generic resource profiles | mysys.generics 
| group | Returns DataFrame with with one dataset profile only | mysys.group('SYS1') |
| groups | Returns DataFrame with all group data | mysys.groups |
| operations | Returns a DataFrame  with all operations users | mysys.operations |
| orphans | Returns 2 DataFrames one with orphans in dataset profile access lists, and one for generic resources | d, g = mysys.orphans |
| orphans | Returns 2 DataFrames one with orphans in dataset profile access lists, and one for generic resources | d, g = mysys.orphans |
| revoked | Returns a DataFrame  with all revoked users | mysys.revoked |
| specials | Returns a DataFrame  with all special users | mysys.specials |
| status | Returns JSON with parsing status | mysys.status |
| uacc_read_datasets | Returns a DataFrame  with all dataset profiles having UACC=READ | mysys.uacc_read_datasets |

# Example use-case

Get all users that have not logged in (on?) since January 1st 2022. And print userID and last logon...

    import time
    mysys = RACF('/path/to/irrdbu00')
    mysys.parse()
    while mysys.status['status'] != 'Ready':
        time.sleep(5)
    selection = mysys.users.loc[mysys.users.USBD_LASTJOB_DATE<="2022-01-01"][['USBD_NAME','USBD_LASTJOB_DATE']]
    for user in selection.values:
      print(f"Userid {user[0]}, last active: {user[1]})

      



